public class Q3 {
  public static void main(String[] args) {
    // Create an AVL tree
    AVLTree<Integer> tree = new AVLTree<>(new Integer[]{15,12,17});
    System.out.print("After inserting 15,12,17:");
    printTree(tree);

    tree.insert(11);
    tree.insert(16);
    System.out.print("\nAfter inserting 11, 16:");
    printTree(tree);

    tree.insert(14);
    tree.insert(19);
    System.out.print("\nAfter inserting 14,19");
    printTree(tree);

    tree.insert(13);
    tree.insert(16);
    System.out.print("\nAfter inserting 13,16");
    printTree(tree);

    tree.delete(17);
    System.out.print("\nAfter removing 17:");
    printTree(tree);

    
    
    System.out.print("\nTraverse the elements in the tree: ");
    for (int e: tree) {
      System.out.print(e + " ");
    }
  }

  public static void printTree(BST tree) {
    // Traverse tree
    System.out.print("\nInorder (sorted): ");
    tree.inorder();
    System.out.print("\nPostorder: ");
    tree.postorder();
    System.out.print("\nPreorder: ");
    tree.preorder();
    System.out.print("\nThe number of nodes is " + tree.getSize());
    System.out.println();
  }
}


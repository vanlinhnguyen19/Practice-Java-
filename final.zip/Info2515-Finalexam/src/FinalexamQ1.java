
public class FinalexamQ1 {
	public static void main(String[] args) {
		
		//create variables
		Integer[] vertices = {0,1,2,3,4};
		int[][] edges = {{0,1},{0,2},{1,0},{1,1},{1,2},{1,3},{1,4},{2,0},{2,1},{2,3},
				{3,1},{3,2},{3,4},{4,3},{4,1}};
	
		
		//create graph and print the size 
		Graph<Integer> graph = new UnweightedGraph<>(vertices, edges);
		System.out.println("The number of vertices in graph: " 
					      + graph.getSize());
		System.out.println("The vertex with index 1 is " 
					      + graph.getVertex(1));
		System.out.println("The edges for graph1:");
					    graph.printEdges();
		
	
}
}

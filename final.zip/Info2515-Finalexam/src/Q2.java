public class Q2 {
  public static void main(String[] args) {
    // Create a BST
    BST<String> tree = new BST<>();
    tree.insert("Helen");
    tree.insert("Bob");
    tree.insert("Nick");
    tree.insert("Emily");
    tree.insert("Jack");
    tree.insert("William");
    tree.insert("Ted");

    //print
    printTree(tree);
    System.out.print("");
    System.out.print("");
    
    
    //delete Nick
    System.out.println("\nAfter delete Nick:");
    tree.delete("Nick");
    printTree(tree);

    
  }
  
  public static void printTree(BST tree) {
	    // Traverse tree
	    System.out.print("Inorder (sorted): ");
	    tree.inorder();
	    System.out.print("\nPostorder: ");
	    tree.postorder();
	    System.out.print("\nPreorder: ");
	    tree.preorder();
	    System.out.print("\nThe number of nodes is " + tree.getSize());
	    System.out.println();
	  }

}


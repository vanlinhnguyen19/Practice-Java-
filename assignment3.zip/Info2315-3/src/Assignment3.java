import java.util.HashMap;

public class Assignment3 {
		public static void main (String[] args) {
				
			//Create map with stu ID and stu name
				HashMap<Integer,String> student = new HashMap<Integer,String>();
				
			//Insert data 
				student.put(100388923, "Linh");
				student.put(100231412, "Brian");
				student.put(100676565, "Justin");
				student.put(100576868, "Nhat");
				student.put(100322135, "Lynn");
				student.put(100987765, "Paul");
				
				System.out.println("Students number and Sudents name: ");
				System.out.println(student + "\n");
				
		}
}

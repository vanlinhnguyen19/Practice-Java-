import java.util.Scanner;

public class Assignment6 {
	public static void main (String[] args) {
		
		//read 10 words
		Scanner sc = new Scanner(System.in);
		System.out.println("Input 10 words in:");
		String[] array = new String[10];
			
			for(int i=0; i<10;i++) {
				array[i]=sc.nextLine();
			}
		
		//create AVL tree
		AVLTree<String> avlTree = new AVLTree<String>();
		fillTree(array,avlTree);
		
		//display tree
		System.out.print("\nInorder: ");
		displayTree(avlTree,"inorder");
		
		System.out.print("\nPreorder: ");
		displayTree(avlTree,"preorder");
		
		System.out.print("\nPostorder: ");
		displayTree(avlTree,"postorder");
	}
	
	private static void fillTree(String[] array, AVLTree<String> tree) {
		for (String word : array) {
			tree.insert(word);
		}
	
	}
	 public static void displayTree(AVLTree<String> tree, String order) {
			 if(order == "inorder")
			 tree.inorder();
			 else if(order == "preorder")
			 tree.preorder();
			 else if(order == "postorder")
			 tree.postorder();
			 else
			 System.out.print("I do not know how to tranverse.");
			 }
	
}

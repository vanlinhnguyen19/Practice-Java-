import java.util.HashMap;
import java.util.Scanner;

public class AssignmentQ2 {
public static void main (String[] args) {
		
		//read 10 words
		Scanner sc = new Scanner(System.in);
		System.out.println("Input 10 words and integers in:");
		String[] array = new String[10];
			
			for(int i=0; i<10;i++) {
				array[i]=sc.nextLine();
			}
			
		//create a map 
		HashMap<String,Integer> map = new HashMap<String,Integer>();
		
		//call HashMap
		fillMap(array,map);
		System.out.println("HashMap: " + map.size());
		System.out.println(map);
}


private static void fillMap(String[] array, HashMap<String,Integer> map) {
	for (int i=1; i<= array.length;i++) {
		map.put(array[i-1],i);
	}

}
}

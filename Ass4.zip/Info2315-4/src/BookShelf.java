import java.util.ArrayList;

class BookShelf{
	
    private ArrayList<Book> bookList = new ArrayList<Book>();
    
    // constructor default
    public  BookShelf(){
        bookList = new ArrayList<Book>();
    }

    // constructor
    public BookShelf(ArrayList<Book> bookList) {
        this.bookList = bookList;
    }

    // get and set methods
    public ArrayList<Book> getBookList() {
        return bookList;
    }

    public void setBookList(ArrayList<Book> bookList) {
        this.bookList = bookList;
    }

    @Override
	public String toString() {
		return "BookShelf [bookList=" + bookList + "]";
	}

    // addBook Method
    public void addBook(Book book){
        this.bookList.add((book));
        System.out.println("Add book to the shelf");
    }

    // removeBook Method
    public void removeBook(Book book){
        this.bookList.remove(book);
        System.out.println("Remove it from the shelf");
    }

    // findBook method
    public boolean findBook(Book book){
        for(Book b : this.bookList){ // use the for loop to iterate over the addbook method
           
        	if(book.equals(b)){ // use if condition check book was found or not 
                System.out.println("Book was found ");
                return true;
                
            }
        }
        System.out.println("Can not find a book");
        return false;
    }
}
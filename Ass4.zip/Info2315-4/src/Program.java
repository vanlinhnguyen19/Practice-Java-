public class Program {

    public static void main(String[] args) {
        //creating bookshlef 
        BookShelf bookShelf = new BookShelf();
        Book book1 = new Book("Math 12",25);
        Book book2 = new Book("History 12",52);
        Book book3 = new Book("Computer 12",64);
        Book book4 = new Book("Physical 12",33);
        Book book5 = new Book("Comunication",55);

        // add books to bookShelf
        bookShelf.addBook(book1);
        bookShelf.addBook(book2);
        bookShelf.addBook(book3);
        bookShelf.addBook(book4);
        bookShelf.addBook(book5);

        //print 
        System.out.println(bookShelf.toString());

        //Test find a book 
        bookShelf.findBook(book3);
        
        //Test remove a book 
        bookShelf.removeBook(book2);
        
        System.out.println(bookShelf.toString());
    }
}
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class Question2 {
	public static void main(String[] args) {
			Set<String> readWord2= new LinkedHashSet<>();
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter 5 words one by one:");
			for(int i =0; i<5;i++) {
				readWord2.add(sc.next());
			}
			
			Iterator<String> displayWords2 = readWord2.iterator();
			while(displayWords2.hasNext()) {
				System.out.println(displayWords2.next());
			}
			System.out.println("Unique words called:"+ readWord2);
	}
}

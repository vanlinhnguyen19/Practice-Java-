/* Name: Van Linh Nguyen 
 * Student number: 100362238
 * Course: INFO2315
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Midterm {
	public static void main(String[] args) {
		
	
		ArrayList<String> readWords = new ArrayList<String>();
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter 5 words one by one:");
		
				for(int i=0; i < 5; i++) {
				readWords.add(sc.next());
		}
	
		
	}
}

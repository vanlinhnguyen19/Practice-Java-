import java.util.Scanner;
import java.util.Stack;

/* We can see here that Jason enters the tunnel first, next is Jack and keep
 * going is Jane and John. Accorording use LIFO, we can see the order they are 
 * entering the tunnel*/
 
public class Question3 {
public static void main(String[] args) {
		
		Stack<String> enterTunnel = new Stack <String>(); 

		enterTunnel.push("Jason");
		enterTunnel.push("Jack");
		enterTunnel.push("Jane");
		enterTunnel.push("John");
		System.out.println("Enter person entering the tunnel: " + enterTunnel);
		
		
		String leaveTunnel = enterTunnel.pop();
		
		System.out.println("Ppl get out of tunnel: \n"+ leaveTunnel);
		
		while(!leaveTunnel.isEmpty()) {
	
				System.out.println(enterTunnel.pop());
			
		}
		}
	}


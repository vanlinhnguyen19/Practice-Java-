import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Question4 {
	public static void main (String[] arg) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Person who severs them: Paul Nguyen \n");
		
		System.out.println("People are waiting in a line : ");
		Queue<String> formLine= new LinkedList<>();
		
		for(int i=0;i<4;i++) {                    
            String name= sc.nextLine();
            formLine.add(name);
    }
		
		System.out.println("Order in a line they will ne serverd: ");
		
		
		Iterator<String> serveLine = formLine.iterator();
		while(serveLine.hasNext()) {
				System.out.println(serveLine.next());
		}
		
		
	}
}	

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Assignment2 {
	public static void main(String[] args) throws FileNotFoundException{
			
		//create new file
			Scanner fileScanner = new Scanner(new File("testtext.txt"));
		
		//create arrayList 
			ArrayList<String> list = new ArrayList<String>();
			
		//adding words to array list
			while(fileScanner.hasNext()) 
				list.add(fileScanner.next());
		//closing text files 
			fileScanner.close();
			
		//reading text files 
			System.out.println("Words before sort:\n" + list);
			
		// how many words in lines
			System.out.println("Number of words in the file: " + list.size());
			System.out.println();
			
			
		
			//sorting the words
			Collections.sort(list);
			
			System.out.println();  
            System.out.println("Words in the text file after Sorting are : ");  
            
         // displaying words in the sorted order 
            
            for(String words: list)  {  
                    
                System.out.println(words);   // displaying words
                       
        }   
	}

}
